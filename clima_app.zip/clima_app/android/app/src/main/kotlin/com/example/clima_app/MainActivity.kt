package com.example.clima_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
